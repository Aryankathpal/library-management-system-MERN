import { useContext, useEffect } from "react"
import { Outlet } from "react-router-dom"
import { Navbar } from "../components/navbar"
import { AuthContext } from "../context/authProvider"
export const HomePage=()=>{

    const {role,token} = useContext(AuthContext);
    useEffect(()=>{
        console.log(role);
        console.log(token);
    },[])
    return(
        <div >
        <Navbar />
        <h1>{role}</h1>
        <h1>{token}</h1>
        {/* <img style={{position:'absolute'}}src={require("../css/lib.jpg")} alt="" className="img-responsive" /> */}
        <Outlet />
        </div>
    )
}